import com.sun.tracing.Provider;

/**
 * Empty interface to get an Provider instance.
 */
public interface BeanProvider extends Provider {
}
